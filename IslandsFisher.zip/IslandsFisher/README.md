# Islands Fisher (Android)
Open this folder in Android Studio (Koala or newer), let Gradle sync, run on a phone (Android 10+).
1. Allow overlay  2. Enable "Islands Fisher" under Accessibility  3. Start (grant screen capture).
Switch to Roblox and press Start on the floating panel.
Reels in the moment the bobber flashes light blue (the bite signal in the game). The app finds the bobber after each cast (fishing line + bobber ball) and moves the red box onto it automatically. If it reels early, raise the sensitivity number; if it misses bites, lower it.

Bite = bobber flashes light blue OR the line end drops ~4px (so it still works when a fish shadow covers the bobber).
